<?php
include_once 'config.php';
// $obj = new UsersModel(); // usersmodel
// $newObj = new ClientsModel();

new AppController;